import 'package:flutter/material.dart';
import 'package:my_assignment/modal.dart';

import 'card.dart';

final List<newCard> myDataList =[

  newCard(title: 'ব্যাচ ৬',
      subtitle: '৬ সিট বাকি',
      Duration: '৬ দিন বাকি', headline: 'Full Stack Web',
      secondline: 'Development With',
      thirdline: 'JavaScript (MERN)',
      ImagePath: 'assets/images/javascript_mern.jpg'),

  newCard(title: 'ব্যাচ ৬',
      subtitle: '৮৬ সিট বাকি',
      Duration: '৪০ দিন বাকি', headline: 'Full Stack Web',
      secondline: 'Development with',
      thirdline: 'Python, Django & React',
      ImagePath: 'assets/images/python_django.jpg'),

  newCard(title: 'ব্যাচ ৭',
      subtitle: '৭৫ সিট বাকি',
      Duration: '৩৯ দিন বাকি', headline: 'Mastering DevOps:',
      secondline: 'From Fundamentals to',
      thirdline: 'Advanced Practices',
      ImagePath: 'assets/images/devosops.jpg'),

  newCard(title: 'ব্যাচ ১৩',
      subtitle: '৬৫সিট বাকি',
      Duration: '৪১দিন বাকি', headline: 'SQA: Manual & ',
      secondline: ' Automated Testing',
      thirdline: '',
      ImagePath: 'assets/images/sql_manual.jpg'),

];
class Backup extends StatelessWidget {
  Backup({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.builder(

        padding: const EdgeInsets.all(12),
        itemCount: myDataList.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 0.6,
        ),
          itemBuilder: (context, index) {
            final data = myDataList[index];
            return newCard(
              title: data.title,
              subtitle: data.subtitle,
              Duration: data.Duration,

              headline: data.headline,
              secondline: data.secondline,
              thirdline: data.thirdline,
              ImagePath: data.ImagePath,
            );
          }
               )



    );
  }
}

